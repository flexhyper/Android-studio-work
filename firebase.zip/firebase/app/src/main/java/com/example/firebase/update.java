package com.example.firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class update extends AppCompatActivity {

    String EmpName, Empno, EmpDept;
    FirebaseDatabase db;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
    }

    private void updateData(String empName, String emno, String empdept){
        HashMap user = new HashMap<>();
        user.put("dept", empdept);
        user.put("name", empdept);
        user.put("number", empdept);
        db = FirebaseDatabase.getInstance();
        reference = db.getReference("updatehelper");
        reference.child(EmpName).updateChildren(user).addOnCompleteListener(new OnCompleteListener() {
            @Override
            public void onComplete(@NonNull Task task) {
                ed1.setText("");
                ed2.setText("");
                ed3.setText("");

                Toast.makeText(update.this, "Data Added", Toast.LENGTH_SHORT).show();
            }
        })
    }
}