package com.example.firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    String EmpName, Empno, EmpDept;

    //Make the Reference variable for firbase database

    FirebaseDatabase db;
    DatabaseReference reference;
    EditText ed1, ed2, ed3;
    Button b1, b2, b3, b4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1 = findViewById(R.id.ed1);
        ed2 = findViewById(R.id.ed2);
        ed3 = findViewById(R.id.ed3);
        b1 = findViewById(R.id.btn1);
        b2 = findViewById(R.id.btn2);
        b3 = findViewById(R.id.btn3);
        b4 = findViewById(R.id.btn4);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EmpName = ed1.getText().toString();
                Empno = ed2.getText().toString();
                EmpDept = ed3.getText().toString();

                if(!EmpName.isEmpty() && !Empno.isEmpty() && !EmpDept.isEmpty()){
                    updatehelper uh = new updatehelper(EmpName, Empno, EmpDept);
                    db = FirebaseDatabase.getInstance();

                    reference = db.getReference("updatehelper");
                    reference.child(EmpName).setValue(uh).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            ed1.setText("");
                            ed2.setText("");
                            ed3.setText("");

                            Toast.makeText(MainActivity.this, "Data Added", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, update.class);
                startActivity(i);
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, display.class);
                startActivity(i);
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, delete.class);
                startActivity(i);
            }
        });
    }
}