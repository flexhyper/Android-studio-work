package com.example.firebase;

public class updatehelper {
    String Name, Number, Dept;

    public updatehelper() {
    }
    public updatehelper(String name, String number, String dept) {
        Name = name;
        Number = number;
        Dept = dept;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getNumber() {
        return Number;
    }

    public void setNumber(String number) {
        Number = number;
    }

    public String getDept() {
        return Dept;
    }

    public void setDept(String dept) {
        Dept = dept;
    }
}
