package com.example.firebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class display extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        ListView l = (ListView) findViewById(R.id.lv);
        final ArrayList<String> list = new ArrayList<>();
        ArrayAdapter ad = new ArrayAdapter<String>(this, R.layout.listview, R.id.tv33);
        l.setAdapter(ad);
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("updatehelper");

    }
}