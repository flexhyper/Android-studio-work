package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button addb = (Button) findViewById(R.id.btn1);
        Button subb = (Button) findViewById(R.id.btn2);
        Button mulb = (Button) findViewById(R.id.btn3);
        Button divb = (Button) findViewById(R.id.btn4);

        //Addition button onclick code
        addb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText e1 = (EditText) findViewById(R.id.ed1);
                EditText e2 = (EditText) findViewById(R.id.ed2);
                TextView t1 = (TextView) findViewById(R.id.tv3);

                int x = Integer.parseInt(e1.getText().toString());
                int y = Integer.parseInt(e2.getText().toString());
                int z = x + y;
                t1.setText("Result: "+ z);
                Toast.makeText(MainActivity.this, "Addition is done", Toast.LENGTH_LONG).show();
            }
        });

        //Subtraction button onclick code
        subb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText e1 = (EditText) findViewById(R.id.ed1);
                EditText e2 = (EditText) findViewById(R.id.ed2);
                TextView t1 = (TextView) findViewById(R.id.tv3);

                int x = Integer.parseInt(e1.getText().toString());
                int y = Integer.parseInt(e2.getText().toString());
                int z = x - y;
                t1.setText("Result: "+ z);
                Toast.makeText(MainActivity.this, "Subtraction is done", Toast.LENGTH_LONG).show();
            }
        });

        //Multiplication button onclick code
        mulb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText e1 = (EditText) findViewById(R.id.ed1);
                EditText e2 = (EditText) findViewById(R.id.ed2);
                TextView t1 = (TextView) findViewById(R.id.tv3);

                int x = Integer.parseInt(e1.getText().toString());
                int y = Integer.parseInt(e2.getText().toString());
                int z = x * y;
                t1.setText("Result: "+ z);
                Toast.makeText(MainActivity.this, "Multiplication is done", Toast.LENGTH_LONG).show();
            }
        });

        //Division button onclick code
        divb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText e1 = (EditText) findViewById(R.id.ed1);
                EditText e2 = (EditText) findViewById(R.id.ed2);
                TextView t1 = (TextView) findViewById(R.id.tv3);

                int x = Integer.parseInt(e1.getText().toString());
                int y = Integer.parseInt(e2.getText().toString());
                int z = x / y;
                t1.setText("Result: "+ z);
                Toast.makeText(MainActivity.this, "Division is done", Toast.LENGTH_LONG).show();
            }
        });
    }
}