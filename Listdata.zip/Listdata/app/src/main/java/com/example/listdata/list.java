package com.example.listdata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        ListView li = findViewById(R.id.lv1);
        Intent i2 = getIntent();
        String[] lidata = i2.getStringArrayExtra(MainActivity.Connect);

        ArrayAdapter<String> ad = new ArrayAdapter<>(this, R.layout.list_data, R.id.tv31, lidata);
        li.setAdapter(ad);
    }
}