package com.example.webview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void shop(View view){
        Button btn = (Button) findViewById(R.id.btn);

        WebView myWebView = (WebView) findViewById(R.id.web);
        myWebView.loadUrl("https://www.amazon.com");
    }
}