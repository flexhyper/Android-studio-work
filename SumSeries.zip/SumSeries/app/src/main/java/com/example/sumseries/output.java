package com.example.sumseries;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class output extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_output);

        TextView tv1 = (TextView) findViewById(R.id.tv11);
        Intent i2 = getIntent();

        float fi = i2.getFloatExtra(MainActivity.Series, 0);

        float sum = 0;
        for(float i = 1; i <= fi; i++){
            sum = sum + (1 / i);
        }

        tv1.setText("Result: Sum of the series is: " + sum);
    }
}