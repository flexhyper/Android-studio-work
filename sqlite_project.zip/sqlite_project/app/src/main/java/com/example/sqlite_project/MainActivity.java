package com.example.sqlite_project;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.widget.TextView;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView tv = (TextView) findViewById(R.id.tv);
        File path = getApplication().getFilesDir();
        String s = path + "/" + "data";
        tv.setText("Database path" + s);
        try {
            db = this.openOrCreateDatabase("data", MODE_PRIVATE, null);
            db.close();
        } catch (SQLiteException e) {
            tv.append("Exception occurred" + e.getMessage());
        }
    }
}