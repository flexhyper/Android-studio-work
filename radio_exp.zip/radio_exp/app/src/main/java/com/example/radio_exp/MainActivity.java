package com.example.radio_exp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup rgg;
    RadioButton rbb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rgg = (RadioGroup) findViewById(R.id.options);
    }

    public void Checked(View view){
        int rid = rgg.getCheckedRadioButtonId();
        rbb = findViewById(rid);
        Toast.makeText(this, "RadioButton selected " + rbb.getText(), Toast.LENGTH_SHORT).show();
    }
}