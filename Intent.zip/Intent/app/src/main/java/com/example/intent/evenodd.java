package com.example.intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class evenodd extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evenodd);

        TextView tvv1 = (TextView) findViewById(R.id.tv12);
        Intent i2 = getIntent();
        int fi = i2.getIntExtra(MainActivity.Number, 0);

        if(fi / 2 == 0){
            tvv1.setText("Result:" + fi + " is Even");
        } else {
            tvv1.setText("Result:" + fi + " is Odd");
        }
    }
}