package com.example.string;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Button len = (Button) findViewById(R.id.btn1);
        //Button trim = (Button) findViewById(R.id.btn2);
        //Button upcase = (Button) findViewById(R.id.btn3);
        //Button lowcase = (Button) findViewById(R.id.btn4);

        /* len.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EEditText ed = (EditText) findViewById(R.id.ed1);
                TextView tvv = (TextView) findViewById(R.id.tv3);
                String tr = ed.getText().toString().replace(" ", "");
                tvv.setText(" " + tr.length());

                Toast.makeText(MainActivity.this, "Length calculated", Toast.LENGTH_SHORT).show();
            }
        }); */

        /* trim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText ed = (EditText) findViewById(R.id.ed1);
                TextView tvv = (TextView) findViewById(R.id.tv3);

                String tr = ed.getText().toString().replace(" ", "");
                tvv.setText(" " + tr);

                Toast.makeText(MainActivity.this, "Trimming done", Toast.LENGTH_SHORT).show();
                    }
        }); */

        /* upcase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText ed = (EditText) findViewById(R.id.ed1);
                TextView tvv = (TextView) findViewById(R.id.tv3);

                String tr = ed.getText().toString().toUpperCase();
                tvv.setText(" " + tr);

                Toast.makeText(MainActivity.this, "converted to uppercase", Toast.LENGTH_SHORT).show();
                    }
        }); */

        /* lowcase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText ed = (EditText) findViewById(R.id.ed1);
                TextView tvv = (TextView) findViewById(R.id.tv3);

                String tr = ed.getText().toString().toLowerCase();
                tvv.setText(" " + tr);

                Toast.makeText(MainActivity.this, "converted to lowercase", Toast.LENGTH_SHORT).show();
            }
        }); */
    }

    public void len(View view){
        EditText ed = (EditText) findViewById(R.id.ed1);
        TextView tvv = (TextView) findViewById(R.id.tv3);
        String tr = ed.getText().toString().replace(" ", "");
        tvv.setText(" " + tr.length());

        Toast.makeText(MainActivity.this, "Length calculated", Toast.LENGTH_SHORT).show();
    }

    public void trim(View view){
        EditText ed = (EditText) findViewById(R.id.ed1);
        TextView tvv = (TextView) findViewById(R.id.tv3);

        String tr = ed.getText().toString().replace(" ", "");
        tvv.setText(" " + tr);

        Toast.makeText(MainActivity.this, "Trimming done", Toast.LENGTH_SHORT).show();
    }

    public void upper(View view){
        EditText ed = (EditText) findViewById(R.id.ed1);
        TextView tvv = (TextView) findViewById(R.id.tv3);

        String tr = ed.getText().toString().toUpperCase();
        tvv.setText(" " + tr);

        Toast.makeText(MainActivity.this, "converted to uppercase", Toast.LENGTH_SHORT).show();
    }

    public void lower(View view){
        EditText ed = (EditText) findViewById(R.id.ed1);
        TextView tvv = (TextView) findViewById(R.id.tv3);

        String tr = ed.getText().toString().toLowerCase();
        tvv.setText(" " + tr);

        Toast.makeText(MainActivity.this, "converted to lowercase", Toast.LENGTH_SHORT).show();
    }
}