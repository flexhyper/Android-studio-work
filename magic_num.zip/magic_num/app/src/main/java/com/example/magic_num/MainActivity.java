package com.example.magic_num;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button fac = (Button) findViewById(R.id.btn1);
        Button oe = (Button) findViewById(R.id.btn2);

        //Factorial code
        fac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText e1 = (EditText) findViewById(R.id.ed1);
                TextView tv = (TextView) findViewById(R.id.tv2);

                int num = Integer.parseInt(e1.getText().toString());
                int fact = 1;
                for (int i = 1; i <= num; i++){
                    fact = fact * i;
                }

                tv.setText("Result: "+ fact);
                Toast.makeText(MainActivity.this, "Factorial performed", Toast.LENGTH_SHORT).show();
            }
        });

        //odd even code
        oe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText e1 = (EditText) findViewById(R.id.ed1);
                TextView tv = (TextView) findViewById(R.id.tv2);

                int num = Integer.parseInt(e1.getText().toString());
                if(num % 2 == 0){
                    tv.setText("Result: Even");
                } else {
                    tv.setText("Result: Odd");
                }
            }
        });
    }
}