package com.example.spinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    public String[] WebSite = {"redditmail.com", "gmail.com", "google.com", "nmims.edu"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spin = (Spinner) findViewById(R.id.spin);
        spin.setOnItemSelectedListener(this);
        ArrayAdapter as = new ArrayAdapter(this, android.R.layout.simple_spinner_item, WebSite);
        as.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(as);

        Button reddit = (Button) findViewById(R.id.btn1);
        Button gmail = (Button) findViewById(R.id.btn2);
        Button google = (Button) findViewById(R.id.btn3);
        Button nmims = (Button) findViewById(R.id.btn4);

    reddit.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            WebView myWebView = (WebView) findViewById(R.id.web);
            myWebView.loadUrl("https://www.reddit.com");
        }
    });

    gmail.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            WebView myWebView = (WebView) findViewById(R.id.web);
            myWebView.loadUrl("https://www.gmail.com");
        }
    });

    google.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            WebView myWebView = (WebView) findViewById(R.id.web);
            myWebView.loadUrl("https://www.google.com");
        }
    });

    nmims.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            WebView myWebView = (WebView) findViewById(R.id.web);
            myWebView.loadUrl("https://www.nmims.edu");
        }
    });
    }
    public void onItemSelected (AdapterView < ? > arg0, View arg1, int position, long id){
        int a  = position + 1;
        Toast.makeText(getApplicationContext(), WebSite[position] + " Button " + a, Toast.LENGTH_SHORT).show();
    }
    public void onNothingSelected (AdapterView < ? > arg0){

    }
}